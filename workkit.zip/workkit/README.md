# 建材询盘背调工作包

解压 workkit.zip，在 Codex 桌面版打开解压后的 workkit 文件夹。用新对话附上 XLSX 或 CSV，并发送：

> 使用 $building-lead-review 处理附件。按原表顺序筛选，保留证据和进度。先出预审表与额度清单。

首轮建议试跑十条新询盘。完成公开背调后，可连接企业授权的 Apollo 账号，确认本批确切地址数及费用后再验证。下载结果后，可人工联系客户并记录反馈。

可直接运行本地队列工具。CSV 只需 Python 3.10+，XLSX 输入可用 Codex 工作区自带 Python 或安装 openpyxl。Excel 结果由 Codex 按技能要求生成。

`python .agents/skills/building-lead-review/scripts/queue.py examples/inquiries.csv local-data`

队列工具输出待查清单和初筛审计。研究证据、验证缓存和反馈保存在 local-data 内，由 Codex 根据技能维护。换电脑时通过公司批准的内部渠道转移该目录。该目录含业务资料。

样例均为虚构数据，只用于检查字段、去重和筛选。
